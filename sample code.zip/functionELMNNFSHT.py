
#funkcija za feature selection i optimiaciju ELM parametara (broj neurona u skrivenom sloju i weights i biases)
#Funkcija moze da radi samo fs+hyper-parameter tuning ili samo hyper-parameter tuning
# 1. Ako je nfeatures=0 i features_list=[naka lista] onda se radi samo hyper-parameters tuning sa odredjenim subset features, jer se koristi lista features dodata preko konstruktora
# 2. Ako je nfeatures=0 i feature_list=[lista svih features, sve jedinice], onda se radi samo hyper-parameters optimization sa svim features
# 3. Ako je nfeatures>0 i features_list=None onda se radi i hyper-parameters-tuning i feature selection


import math
import numpy as np
from utilities.load_dataset import load_dataset
from ml_models.ELM import  ELM


#ako se ne radi feature selection, onda nfeatures mora biti 0 i features_list mora biti lista preselektovanih features
class ELMFunction:
    def __init__(self, D, no_classes,nfeatures, fitness_type,alpha,x_train,x_test,y_train,y_test,intParams, lb_w=-1,ub_w=1,lb_nn=1,ub_nn=1000,nn=50,features_list=None):
        #D is number of parameters (input feature size * number of hidden unit neurons)
        #lb_w, ub_w - lower and upper bound of weights
        #lb_nn, ub_nn lower and upper bounds of neurons in the hidden layer
        #no_classes number of classes in the dataset
        self.no_classes = no_classes
        #ovo smo ostavili u slucaju da hocemo da testiramo sa fiksnim brojem neurona
        self.nn = nn
        #the number of features in the dataset
        self.nfeatures = nfeatures

        #koji objective koristimo, ovo mora biti prvi parametar koji se vraca
        #moze kombinacija broja features i error rate-a, posto se radi o minimizaciji
        #fitness type - 0 je samo error, a 1 je composite error i number of features
        self.fitness_type = fitness_type
        #ovo su weighted coefficient za error i broj selektovanih features
        self.alpha = alpha
        self.beta = 1-alpha #alpha je obicnao za error, a beta je obicno za broj feature-a

        #intParams je lista sa pozicijama parametara (indeksima) za swarm resenje koji treba da budu integer
        self.intParams = intParams


        #D treba postaviti na max broj D iz spoljasnjeg koda, sto je upper bound za broj nfeatures + upper_bound za broj neurona + neurona*feature_size +


        #self.x_train, self.y_train, self.x_test, self.y_test = load_dataset(path_train, path_test, self.no_classes, normalize, test_size)

        self.x_train=x_train
        self.y_train=y_train
        self.x_test=x_test
        self.y_test = y_test

        #ovo nam koristi za solution
        self.y_test_length = len(y_test)

        self.D = D
        #D is weighs*input features length + 1
        #in second experiment we use NN as well as the first argument of solution
        self.lb_w = lb_w
        self.ub_w = ub_w
        self.lb_nn= lb_nn
        self.ub_nn = ub_nn

        #ako se radi bez feature selection, onda se prosledjuje features list
        #dakle, ako je features_list=None (po default), onda se radi fs i optimizacija, a ako ima necega, onda se radi samo optimizacija
        #za svaki slucaj konvertujemo sve elemente u int
        self.features_list = [int(x) for x in features_list]
        print(self.features_list)

        self.ub = [None] * self.D
        self.lb = [None] * self.D
        self.minimum = 0
        self.solution = '(0,...,0)'
        self.name = "ELMFunction"

        #pomocna promenljiva koja pokazuje da li radimo feature selection
        #postavljamo ovu promenjivu samo na osnovu neatures
        if self.nfeatures>0:
            self.fs = True
        else:
            self.fs = False

        # solution encoding: s[0:nfeatures] - broj features u datasetu
        # s[nfeatures] - broj neurona
        #s[nfeatures+1:D] - weights i biases

        #prvo idu lower i upper bounds za features (lower 0, upper 1), ali u zavisnosti od toga da li je se radi feature selection ili ne
        # dakle, ako je features_list=None (po default), onda se radi fs i optimizacija, a ako ima necega, onda se radi samo optimizacija

        #prvo gledamo da li se radi feature selection

        #PRVO DEFINISEMO GRANICE PARAMETARA AKO RADIMO FEATURE SELECTION
        if self.fs:
            for i in range(self.nfeatures):
                self.lb[i] = 0
                self.ub[i] = 1
            #ub[nfeatures] i lb[nfeatures] je za broj neurona
            # ovo je hiperparametar
            self.lb[nfeatures] = self.lb_nn
            self.ub[nfeatures] = self.ub_nn
         # onda ide za weights i biases
            for i in range(nfeatures+1, self.D):
                self.lb[i] = self.lb_w
                self.ub[i] = self.ub_w
        #SADA DEFINISEMO PARAMETRE AKO SE NE RADI FEATURE SELECTION
        else:
            #print("OVO RADI")
            #onda je nfeatures=0 prvi parametar i to je broj neurona (integer)
            self.lb[nfeatures] = self.lb_nn
            self.ub[nfeatures] = self.ub_nn
            # onda ide za weights i biases
            for i in range(nfeatures + 1, self.D):
                self.lb[i] = self.lb_w
                self.ub[i] = self.ub_w

        #elm.initWeights()
        #elm.train()
        #y_proba, y = elm.predict1()



    def function(self, x):
        x = np.array(x)
        # initialization of ELM
        #treci argument je broj neurona, a broj neurona bice prvi parameter od x x[0], pa se uradi round
        #zaokruzujemo na integer
        #self.nn je uvek na poziciji nfeatures, bez obzira da li se radi ili se ne radi feature selection
        #print(x[self.nfeatures],"ELM")
        self.nn = int(x[self.nfeatures]) #za svaki slucaj eksplicitno konvertujemo
        #print(self.nn,"ELM")
        #print(self.nn)
        #self.nn = int(np.rint(x[self.nfeatures]))
        #ovde sada definisemo ELM ali uzimamo u obzir features koji su selektovani
        #prvo pravimo novi dataset na osnovu broja features, to su x_train_fs i x_test_fs
        #sada definisemo novi x_train i x_test u zavisnosti od toga da li radimo ili ne radimo feature selection
        #prvo definisemo ako radimo fs
        if self.fs:
            x_train_fs = self.x_train[:, x[0:self.nfeatures] == 1]
            x_test_fs = self.x_test[:, x[0:self.nfeatures] == 1]
            #broj odabranih featrues
            feature_size = np.sum(x[0:self.nfeatures])

            if feature_size==0:
                return 1,1,0,0,0

        #sada gledamo ako ne radimo feature selection i onda gledamo unapred prosledjenu listu features, koja predstavlja koji se features uzimaju u obzir
        else:
            #print("OVO RADI")
            x_train_fs = self.x_train[:, np.array(self.features_list) == 1]
            x_test_fs = self.x_test[:, np.array(self.features_list) == 1]
            # broj odabranih featrues
            feature_size = np.sum(self.features_list)
            #print(x_train_fs.shape[1])
            #print(x_train_fs)
            #ovo za svaki slucaj ako neko prosledi sve nule
            if feature_size==0:
                return 1,1,0,0,0

        #print(type(self.nn), " ovo je vrednost: ", self.nn)


        elm = ELM(x_train_fs.shape[1], self.no_classes,self.nn,'relu',x_train_fs,x_test_fs,self.y_train,self.y_test)


        #elm = ELM(self.x_train.shape[1], self.no_classes, nn, 'relu', self.x_train, self.x_test, self.y_train, self.y_test)

        #prvi argument je broj neurona, pa onda izbacujemo prvi argument iz niza

        elm.setWeights(x[self.nfeatures+1:])
        #elm.setWeights(x[1:])
        elm.train()
        #returns classification error, y_probabilities and y as dummy (1,0,0)


        error,y_proba,y = elm.predict1()


        #ovo je samo error i prvi se vraca fitness, koji je isto sto i error
        #vraca se uvek u sledecem redosledu: 1. fitness, 2. error, y_proba,y, feature_size
        #kada je fitness_type==0, onda je prvi samo error
        if self.fitness_type == 0:
            return (error,error,y_proba,y,feature_size)
        else:
            objective = self.alpha*error + self.beta*(feature_size/self.nfeatures) #ovo je za minimization
            return (objective,error,y_proba,y,feature_size)






