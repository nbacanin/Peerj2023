import csv
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import roc_curve, auc
from scipy import interp
import pickle
from scipy import stats
from sklearn.metrics import roc_auc_score
from itertools import cycle
from itertools import *
import itertools
from sklearn.metrics import precision_recall_curve
from sklearn.metrics import average_precision_score
from sklearn.metrics import f1_score
from sklearn.metrics import auc
from sklearn.metrics import multilabel_confusion_matrix
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report

#klasa za posprocessing, zapis rezultata u csv i vizualizacija
class Postprocessing:

    def __init__(self,statistics_array,path,x_test,y_test,classes,styles,markers,display_features=False,plot_iter=1,model_name=None):
        #podesavamo matplotlib layout
        plt.figure(figsize=(8, 6), dpi=240)
        plt.tight_layout()

        #setujemo color palette za sns
        sns.color_palette('tab10')

        self.model_name = model_name

        #ovo je niz statistics objekata u kojem se nalaze podaci za sve metode
        #dakle, broj objekata u nizu je jednak broju metoda koje smo koristili u simulaciji
        self.statistics_array = statistics_array
        #ovo je putanja do foldera gde se cuvaju rezultati
        self.path = path
        #cuvamo styles i markers za convergence
        self.styles = styles
        self.markers = markers

        #plot_iter da li hocemo da plotujemo svaku n-th iteraciju
        self.plot_iter = plot_iter

        #da li prikazujemo features na grafovima
        self.display_features = display_features

        #sami citamo iz statistics objekta iter_number
        self.iter_number = len(self.statistics_array[0].best_run_convergence_objective)

        #sada citamo run number da vidimo koliko imamo runova
        self.run_number = len(self.statistics_array[0].run_array_best)

        #postaljanje y_test
        self.y_test = y_test
        #postavljanje x_test, treba nam za OvR i OvO
        self.x_test = x_test
        #treba nam i y_test_classes (y_test je za svaku instancu ima onoliko indexa koliko i klasa, a nama treba 1-dim niz, npr. y=[0,1,0,1,2]
        self.y_test_classes = self.convertY_test()
        #postavljenje klasa za labele, lista duzine koliko ima klasa, gde svaka klasa ima svoj label
        self.classes = classes

        #globalna lista za cuvanje statistika i metika za ROC i PR curves
        self.global_roc_pr_statistics = []
        #prvo dodajemo dictionary za svaki metod i method name dodajemo
        for i in range(len(self.statistics_array)):
            self.global_roc_pr_statistics.append({'Method':self.statistics_array[i].method})




        #prvo pravimo csv sa overall statistikom
        self.overallStatistics()


        #sada generisemo dataframes za convergence
        self.generate_convergence_df()

        #sada plotujemo convergence graphs
        self.plot_convergence_graphs()

        #sada pravimo CM za najbolje resenje
        self.plot_confusion_matrix()

        # sada pravimo csv sa detaljnim metrikama

        self.calculateDetailedMetrics()

        #sada pravimo classification report

        self.generateClassificationReport()



        #generisanje ROC krive
        self.calculate_ROC_curve()

        #sada pravimo PR curve
        self.calculate_PR_curve()

        #sada pravimo i df i csv sa best runovima za objective i error
        self.generate_best_run_df()

        #sada plotujemo box plot diagrame

        self.generateBoxPlot()

        #sada pravimo i violin plo
        self.generateViolinPlot()

        # sada cuvamo u csv best diversity, diversity populacije u najbolje runu

        self.generate_best_diversity()

        # sada plotujemo joint plot za diversity, na jednoj osi objective u poslednjoj populaciji za sva resenja, a na drugoj osi indicator (objective najverovatnije mse, indicator je R2)
        # ali se podesava, zavisi

        self.plotJointPlot()

        # sada plotujemo i swarm plot za diversity u poslednjoj populaciji i to jedan za objective (najverovatnije mse), drugi za R2 (najverovatnije R2)
        # ali se podesava, zavisi

        self.generateSwarmPlotsDiversity()


        #plot ROC OvR za sve metode
        self.plotROCOvR()

        self.plotROCOvO()

        #sada cuvamo PR ROC globalne statisitke

        self.savePRROCstatistics()

        #sada generisemo KDE plots
        self.generateKDEPlot()

        # sada cuvamo najbolje modele
        # sada cuvamo najbolje modele
        self.saveBestModels()




    #pomocna metoda za zapisivanje statistike best, mean, worst, std, var, feature_size, parameters u csv fajl
    def overallStatistics(self):
        #pravimo listu sa statistikom za svaki objekat statistics u nizu (svaki metod) svaki element liste je dictionary
        #svaki element (dictionary) odgovara jednom metodu
        statistics_list = []

        full_file_name = self.path + '/' + self.statistics_array[0].dataset + ' ' + self.statistics_array[0].problem + ' ' + self.statistics_array[0].objective + ' overall metrics.csv'

        for i in range(len(self.statistics_array)):
            statistics_list.append({'Method':self.statistics_array[i].method,'Best':(1-self.statistics_array[i].best_run),
                                    'Worst':(1-self.statistics_array[i].worst_run),'Mean':(1-self.statistics_array[i].mean_run),
                                    'Median':(1-self.statistics_array[i].median_run),'Std':self.statistics_array[i].std_run,
                                    'Var':self.statistics_array[i].var_run, 'Best1':self.statistics_array[i].best_run1, 'Worst1':self.statistics_array[i].worst_run1,
                                    'Mean1':self.statistics_array[i].mean_run1, 'Median1':self.statistics_array[i].median_run1, 'Std1':self.statistics_array[i].std_run1,
                                    'Var1':self.statistics_array[i].var_run1,'Best feature size':self.statistics_array[i].best_feature_size,'Params':self.statistics_array[i].best_params,
                                    'y proba':self.statistics_array[i].best_y_proba.ravel().tolist()})
            #niz za headers csv fajla
            headers = ['Method', 'Best', 'Worst','Mean','Median','Std','Var','Best1', 'Worst1','Mean1','Median1','Std1','Var1','Best feature size','Params','y proba']

            #naziv fajla, uzimamo path pa dodajemo


            with open(full_file_name, 'w', newline='') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=headers)
                writer.writeheader()
                writer.writerows(statistics_list)




        #pomocni metod za generisanje pd.DataFrame za convergence
    def generate_convergence_df(self):

        #pravimo 2 liste, jednu za objective convergence u najboljem runu, a drugi za error convergence u najboljem runu
        #i jednu listu za headere, tj. nazive metoda
        objective_convergence = []
        error_convergence = []
        headers = ['Iterations']
        #dodajemo prvu kolonu da budu iteracije od 1 pa nadalje,ali krecemo od 1, ne od 0
        objective_convergence.append(np.array([x for x in range(1,self.iter_number+1)]))
        error_convergence.append(np.array([x for x in range(1, self.iter_number+1)]))
        #sada ubacujemo elemente u liste
        for i in range(len(self.statistics_array)):
            objective_convergence.append((1-self.statistics_array[i].best_run_convergence_objective))
            error_convergence.append(self.statistics_array[i].best_run_convergence_error)
            headers.append(self.statistics_array[i].method)

        #dodajemo jos jedan isti red da bi se graf lepo prikazao da ide do kraja
        #objective_convergence.append(self.statistics_array[i].best_run_convergence_objective[-1])
        #error_convergence.append(self.statistics_array[i].best_run_convergence_error[-1])


        #sada cuvamo dataframe
        self.objective_covergence_df = pd.DataFrame(data=objective_convergence,index=None).T
        self.error_convergence_df = pd.DataFrame(data=error_convergence,index=None).T
        self.objective_covergence_df.columns = headers
        self.error_convergence_df.columns = headers

        full_file_name_error = self.path + '/' + self.statistics_array[0].dataset + ' ' + self.statistics_array[
            0].problem + str(self.statistics_array[0].dataset) + ' convergence graph.csv'

        full_file_name_objective = self.path + '/' + self.statistics_array[0].dataset + ' ' + self.statistics_array[
            0].problem + ' objective convergence graph.csv'

        self.error_convergence_df.to_csv(full_file_name_error)
        self.objective_covergence_df.to_csv(full_file_name_objective)


    #pomocna funkcija za plotovanje convergence speed grafova

    def plot_convergence_graphs(self):
        # methods - python list of methods ['SCA','FA']
        # path - path to results in form of csv file, where unnamed column is 1st column and this will be index
        # string name of the function for title
        # iterations - maximum number of iterations
        # methods list must match columns in csv file
        # styles - line styles for plotting
        plt.clf()
        plt.figure(figsize=(12,8),dpi=300)

        #prvo plotujemo za objective
        for i in range(len(self.statistics_array)):
            plt.plot(self.objective_covergence_df[self.statistics_array[i].method][::self.plot_iter],self.styles[i],label=self.statistics_array[i].method,marker=self.markers[i],
                     linewidth=1, markersize=2,alpha=0.9
                     )
            
        plt.title(self.statistics_array[0].dataset + ' objective convergence graphs')
        plt.xlim([0, self.iter_number-1])
        plt.ylabel('Objective')
        plt.xlabel('Iterations')
        plt.legend(loc='upper right')

        full_file_name_objective = self.path + '/' + self.statistics_array[0].dataset + ' ' + self.statistics_array[
            0].problem + ' objective convergence graph.pdf'

        # plt.legend()
        plt.savefig(full_file_name_objective,bbox_inches='tight')

        #clear figure
        plt.clf()
        plt.figure(figsize=(12, 8), dpi=300)

        #sada plotujemo za error

        for i in range(len(self.statistics_array)):
            plt.plot(self.error_convergence_df[self.statistics_array[i].method][::self.plot_iter],self.styles[i],label=self.statistics_array[i].method,marker=self.markers[i],
                     linewidth=1, markersize=2,alpha=0.9
                     )

        plt.title(self.statistics_array[0].dataset + ' ' + self.statistics_array[0].indicator + ' convergence graphs')
        plt.xlim([0, self.iter_number-1])
        plt.ylabel(str(self.statistics_array[0].indicator))
        plt.xlabel('Iterations')
        plt.legend(loc='upper right')

        full_file_name_objective = self.path + '/' + self.statistics_array[0].dataset + ' ' + self.statistics_array[
            0].problem + ' ' + self.statistics_array[0].indicator + ' convergence graph.pdf'

        # plt.legend()
        plt.savefig(full_file_name_objective,bbox_inches='tight')
        plt.clf()

    # metoda za plotting confusion matrix
    #y_proba su probabilites, y je u formi za binary [0,1], [1,0], itd. a y_classes je u formi [0,1,0,1,0,1,...]
    def plot_confusion_matrix(self, normalize=True, cmap=plt.cm.Blues):
        #sada idemo kroz svako resenje i plotujemo odgovarajucu cm
        cmap = plt.cm.Greens
        for i in range(len(self.statistics_array)):
            #generisemo y_test_classes i y pomocu dole navedene metode koja kao argument prima best solution y_proba
            y,y_classes = self.generateY(self.statistics_array[i].best_y_proba)
            #cm = confusion_matrix(self.y_test_classes, y_classes)
            cm = confusion_matrix(y_classes,self.y_test_classes)
            full_file_name_cm = self.path + '/' + self.statistics_array[i].method + ' ' + self.statistics_array[0].dataset + ' ' \
                                       + self.statistics_array[0].problem + ' confusion matrix.pdf'
            title = self.statistics_array[i].method + ' ' + self.statistics_array[i].dataset + ' confusion matrix'

            if self.display_features:
                title = title + ' \n (' + str(
                round(self.statistics_array[i].best_feature_size, 0)) + ' sel.feat.)'

            #if i==1:
            #print(f'solution:{i} \n y:{y} \n y_classes:{y_classes} \n  solution y: {self.statistics_array[i].best_solution.y} \n ****\n')





            if normalize:
                cm = np.round(cm.astype('float') / cm.sum(axis=1)[:, np.newaxis],3)

                #conf_mat_norm = np.around(conf_mat.astype('float') / conf_mat.sum(axis=1)[:, np.newaxis], decimals=2)
                #print("Normalized confusion matrix")
            else:
                pass
                #print('Confusion matrix, without normalization')

        #print(cm)

            plt.imshow(cm, interpolation='nearest', cmap=cmap)
            plt.title(title)
            plt.colorbar()
            tick_marks = np.arange(len(self.classes))
            plt.xticks(tick_marks, self.classes, rotation=45)
            plt.yticks(tick_marks, self.classes)

            fmt = '.3f' if normalize else 'd'
            thresh = cm.max() / 2.
            plt.tight_layout()
            for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
                plt.text(j, i, format(cm[i, j], fmt),
                     horizontalalignment="center",
                     color="white" if cm[i, j] > thresh else "black")

            plt.ylabel('True label')
            plt.xlabel('Predicted label')

            plt.savefig(full_file_name_cm, bbox_inches='tight')

            plt.clf()

    #pomocna metoda za konverziju y_test u y_test_classes
    def convertY_test(self):
        y_test_classes = np.zeros(self.y_test.shape[0])
        for i in range(self.y_test.shape[0]):
            y_test_classes[i] = np.argmax(self.y_test[i])
        return y_test_classes

    #pomocna metoda za konverziju y_proba (to je element najboljeg resenja) u y, pa potom u y_classes, kao sto imamo y_test_classes
    #argument je y_proba niz svakog best solutiona
    #ovo se koristi kasnije za generisanje cm i ostalog za svako resenje
    def generateY(self,y_proba):
        y = np.zeros((len(y_proba), y_proba.shape[1]))
        for i in range(len(y_proba)):
            y[i][np.argmax(y_proba[i])] = 1
        y_classes = np.zeros(y.shape[0])
        for i in range(y.shape[0]):
            y_classes[i] = np.argmax(y[i])
        #vraca par y,y_classes
        return (y,y_classes)

    #pomocna metoda za racunanje detaljnih metrika najboljeg resenja
    def calculateDetailedMetrics(self):
        # extracting performance
        # link: https://towardsdatascience.com/multi-class-classification-extracting-performance-metrics-from-the-confusion-matrix-b379b427a872
        #sada nam opet treba cm za svako najbolje resenje

        for i in range(len(self.statistics_array)):
            #generisemo y_test_classes i y pomocu dole navedene metode koja kao argument prima best solution y_proba
            y,y_classes = self.generateY(self.statistics_array[i].best_y_proba)
            cm = confusion_matrix(self.y_test_classes, y_classes)
            full_file_name_dm = self.path + '/' + self.statistics_array[i].method + ' ' + self.statistics_array[0].dataset + ' ' \
                                       + self.statistics_array[0].problem + ' detailed metrics.csv'

        #sada racunamo sve metrike na osnovu CM

            FP = cm.sum(axis=0) - np.diag(cm)
            FN = cm.sum(axis=1) - np.diag(cm)
            TP = np.diag(cm)
            TN = cm.sum() - (FP + FN + TP)
            FP = FP.astype(float)
            FN = FN.astype(float)
            TP = TP.astype(float)
            TN = TN.astype(float)
            # Sensitivity, hit rate, recall, or true positive rate
            TPR = TP / (TP + FN)
            TPR = np.round(TPR, 3)
            # Specificity or true negative rate
            TNR = TN / (TN + FP)
            TNR = np.round(TNR, 3)
            # Precision or positive predictive value
            PPV = TP / (TP + FP)
            PPV = np.round(PPV, 3)
            # Negative predictive value
            NPV = TN / (TN + FN)
            NPV = np.round(NPV, 3)
            # Fall out or false positive rate
            FPR = FP / (FP + TN)
            FPR = np.round(FPR, 3)
            # False negative rate
            FNR = FN / (TP + FN)
            FNR = np.round(FNR, 3)
            # False discovery rate
            FDR = FP / (TP + FP)
            FDR = np.round(FDR, 3)
            # F1-SCORE
            # F-Measure = (2 * Precision * Recall) / (Precision + Recall)
            F_SCORE = (2 * PPV * TPR) / (PPV + TPR)
            F_SCORE = np.round(F_SCORE, 3)
            # Overall accuracy for each class
            # ACC = (TP + TN) / (TP + FP + FN + TN)
            ACC_TOTAL_CLASSES_ROUNDED= np.round((TP + TN) / np.sum(cm),3)
            #ACC = np.round(ACC, 3)
            # total accuracy for all classes
            # ACC_TOTAL = (np.sum(TP) + np.sum(TN)) / (np.sum(TP) + np.sum(TN) + np.sum(FP) + np.sum(FN))
            ACC_TOTAL_CLASSES = (TP + TN) / (TP + TN + FP + FN)
            #ACC_TOTAL = ACC_TOTAL

        # druga metoda
        # ovo je dobra metoda za racunanje accuracy na osnovu confusion matrix

            diagonal_sum = cm.trace()
            sum_of_all_elements = cm.sum()
            ACC_TOTAL = diagonal_sum / sum_of_all_elements
            ERROR_TOTAL = 1-ACC_TOTAL
            ERROR_TOTAL_CLASSES = 1-ACC_TOTAL_CLASSES

            dict = {"FP": FP, "FN": FN, "TP": TP, "TN": TN, "TPR": TPR, "TNR": TNR, "PPV": PPV, "NPV": NPV, "FPR": FPR,"FNR": FNR,
                    "FDR": FDR, "F_SCORE": F_SCORE, "ACC_TOTAL_CLASSES_ROUNDED": ACC_TOTAL_CLASSES_ROUNDED, "ACC_TOTAL_CLASSES": ACC_TOTAL_CLASSES, "ACC_TOTAL": ACC_TOTAL,"ERROR_TOTAL":ERROR_TOTAL,"ERROR_TOTAL_CLASSES":ERROR_TOTAL_CLASSES}

            pd.DataFrame(dict).reset_index().to_csv(full_file_name_dm, index=False)

    #pomocna metoda za generisanje classification reporta
    def generateClassificationReport(self):
        #idemo kroz sve metode
        for i in range(len(self.statistics_array)):
            #generisemo y_test_classes i y pomocu dole navedene metode koja kao argument prima best solution y_proba
            y,y_classes = self.generateY(self.statistics_array[i].best_y_proba)
            cr = classification_report(self.y_test_classes, y_classes,output_dict=True)
            df = pd.DataFrame(cr)
            full_file_name_cr = self.path + '/' + self.statistics_array[i].method + ' ' + self.statistics_array[
                0].dataset + ' ' + self.statistics_array[0].problem + ' cr.csv'
            df.to_csv(full_file_name_cr)

    #pomocna funkcija za plotovanje ROC krive i ROC AUC

        # dobra funkcija
        # funkcija za plotovovanje ROC curve and ROC area za svaku klasu
        # link
        # https://scikit-learn.org/stable/auto_examples/model_selection/plot_roc.html
        # ovde racunamo sa y_proba, sa probabilities i prikazujemo i macro i micro
        # treba da ide sa y_proba, nije dovoljno samo y
        # definitino treba sa y_proba
        # ovo je za racunarnje ROC curve
    def calculate_ROC_curve(self):
        #idemo kroz sve statistike, svih algoritama
        #ovo je list za statistiku, gde cuvamo najbolje pokazatelje ROC AUC za sve klase, micro i macro average roc
        #statistics_list = []

        for i in range(len(self.statistics_array)):
            n_classes = len(self.classes)
            # Compute ROC curve and ROC area for each class
            fpr = dict()
            tpr = dict()
            roc_auc = dict()
            for j in range(n_classes):
                # ide y_test kao dummy (0,0,1)
                fpr[j], tpr[j], _ = roc_curve(self.y_test[:, j], self.statistics_array[i].best_y_proba[:,j])
                roc_auc[j] = auc(fpr[j], tpr[j])

            # Compute micro-average ROC curve and ROC area
            fpr["micro"], tpr["micro"], _ = roc_curve(self.y_test.ravel(), self.statistics_array[i].best_y_proba.ravel())
            roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])

            # Plot ROC curve
            plt.clf()
            #plt.figure()
            plt.plot(fpr["micro"], tpr["micro"],
                     label='micro-average ROC curve (area = {0:0.3f})'
                           ''.format(roc_auc["micro"]))
            for j in range(n_classes):
                plt.plot(fpr[j], tpr[j], label='ROC curve of class {0} (area = {1:0.3f})'
                                               ''.format(self.classes[j], roc_auc[j]))
            #plt.tight_layout()
            plt.plot([0, 1], [0, 1], 'k--')
            plt.xlim([0.0, 1.0])
            plt.ylim([0.0, 1.05])
            plt.xlabel('False Positive Rate')
            plt.ylabel('True Positive Rate')

            title = self.statistics_array[0].dataset + ' micro average ROC'
            if self.display_features:
                title = title + ' \n (' + str(round(self.statistics_array[i].best_feature_size, 0)) + ' sel.feat.)'

            plt.title(title)

            # plt.title('Some extension of Receiver operating characteristic to multi-class')
            plt.legend(loc="lower right")
            full_file_name_roc = self.path + '/' + self.statistics_array[i].method + ' ' + self.statistics_array[
                0].dataset + ' ' \
                                + self.statistics_array[0].problem + ' micro ROC.pdf'


            title = self.statistics_array[i].method + ' ' + self.statistics_array[
                i].dataset + ' micro average ROC'

            if self.display_features:
                title = title +  ' \n (' + str(
                round(self.statistics_array[i].best_feature_size, 0)) + ' sel.feat.)'

            plt.title(title)

            plt.savefig(full_file_name_roc, bbox_inches='tight')
            # plt.show()

            # Compute macro-average ROC curve and ROC area

            # First aggregate all false positive rates
            all_fpr = np.unique(np.concatenate([fpr[i] for i in range(n_classes)]))

            # Then interpolate all ROC curves at this points
            mean_tpr = np.zeros_like(all_fpr)
            for j in range(n_classes):
                mean_tpr += interp(all_fpr, fpr[j], tpr[j])

            # Finally average it and compute AUC
            mean_tpr /= n_classes

            fpr["macro"] = all_fpr
            tpr["macro"] = mean_tpr
            roc_auc["macro"] = auc(fpr["macro"], tpr["macro"])

            # Plot all ROC curves
            plt.clf()
            #plt.figure()
            plt.plot(
                fpr["micro"],
                tpr["micro"],
                label="micro-average ROC curve (area = {0:0.3f})".format(roc_auc["micro"]),
                color="deeppink",
                linestyle=":",
                linewidth=4,
            )

            plt.plot(
                fpr["macro"],
                tpr["macro"],
                label="macro-average ROC curve (area = {0:0.3f})".format(roc_auc["macro"]),
                color="navy",
                linestyle=":",
                linewidth=4,
            )

            colors = cycle(["aqua", "darkorange", "cornflowerblue"])
            for j, color in zip(range(n_classes), colors):
                plt.plot(
                    fpr[j],
                    tpr[j],
                    color=color,
                    lw=2,
                    label="ROC curve of class {0} (area = {1:0.3f})".format(self.classes[j], roc_auc[j]),
                )


            #plt.tight_layout()
            plt.plot([0, 1], [0, 1], "k--", lw=2)
            plt.xlim([0.0, 1.0])
            plt.ylim([0.0, 1.05])
            plt.xlabel("False Positive Rate")
            plt.ylabel("True Positive Rate")
            full_file_name_roc = self.path + '/' + self.statistics_array[i].method + ' ' + self.statistics_array[
                0].dataset + ' ' \
                                 + self.statistics_array[0].problem + ' macro-micro ROC.pdf'
            title = self.statistics_array[i].method + ' ' + self.statistics_array[
                i].dataset + ' macro-micro average ROC'
            if self.display_features:
                title = title +  ' \n (' + str(round(self.statistics_array[i].best_feature_size, 2)) + ' sel.feat.)'

            plt.title(title)
            # plt.title("Some extension of Receiver operating characteristic to multiclass")
            plt.legend(loc="lower right")

            plt.savefig(full_file_name_roc, bbox_inches='tight')
            # plt.show()

            #print(roc_auc[0])
            #print(type(roc_auc))
            #print(str(roc_auc))
            #statistics_list.append({"Method":self.statistics_array[i].method,"ROC metrics:":str(roc_auc)})

            #sada cuvamo pokazatelje u globalnu listu
            self.global_roc_pr_statistics[i]['ROC AUC']=str(roc_auc)




    #pogledati ovo za ROC za Ovo i Ovr
    #https://github.com/vinyluis/Articles/blob/main/ROC%20Curve%20and%20ROC%20AUC/ROC%20Curve%20-%20Multiclass.ipynb
    #https: // towardsdatascience.com / multiclass - classification - evaluation - with-roc - curves - and -roc - auc - 294fd4617e3a





        # DOBRA FUNKCIJA A GENERISANJE AUC ZA PRECISION RECALL (PR KRIVU)
        # VRACA I F1 SCORE I AVERAGE PRECISION (AUC) ZA SVE KLASE POJEDINACNO
        # funkcija za racunanje average precision za sve klase posebno i micro average precision
        # i generise PR  krive i racuna AUC za PR
        # OVO JE ODLICNA FUNKCIJA I TREBA JE KORISTIT
        # FUNKCIJA ZA PR CURVE
    def calculate_PR_curve(self):
        '''
        can be used for calculating fitness function
        function that calculates average precision for all classes
        inputs: n_classes - number of classes
        y_test - y_test label encoded, must be transformed into dummies and np.array
        y_test must be in a form of numpy.array
        y_proba - predicted probabilities for all classes obtained by model.predict_proba()
        #link:https://stats.stackexchange.com/questions/534431/calculating-area-under-the-precision-recall-curve-with-multiclass/535030
        y_pred - predvidjene integer klase, koristi se za f1 score
        '''

        for i in range(len(self.statistics_array)):

            n_classes = len(self.classes)
            # For each class
            precision = dict()
            recall = dict()
            average_precision = dict()
            auc_score = dict()
            f1_result = dict()
            # transofrming y_test into dummy
            # x = pd.get_dummies(y_test)
            # x = np.array(x)

            # y = pd.get_dummies(y_pred)
            # y = np.array(y)

            # generisemo y_test_classes i y pomocu dole navedene metode koja kao argument prima best solution y_proba
            y, y_classes = self.generateY(self.statistics_array[i].best_y_proba)

            plt.clf()

            for j in range(n_classes):
                precision[self.classes[j]], recall[self.classes[j]], _ = precision_recall_curve(self.y_test[:, j],
                                                                                                self.statistics_array[i].best_y_proba[:, j])

                average_precision[self.classes[j]]= average_precision_score(self.y_test[:, j],self.statistics_array[i].best_y_proba[:, j])

                # auc_score i isto sto i average_precision
                # average_precision je Area Under the Curve za pojedinacne klase, ovo je dobro
                auc_score[self.classes[j]] = auc(recall[self.classes[j]], precision[self.classes[j]])

                f1_result[self.classes[j]] = f1_score(self.y_test[:, j], y[:, j])

                plt.plot(precision[self.classes[j]], recall[self.classes[j]], lw=1,
                         label='{} AP:{:.3f}'.format(self.classes[j], average_precision[self.classes[j]]))

            # A "micro-average": quantifying score on all classes jointly
            precision["micro"], recall["micro"], _ = precision_recall_curve(self.y_test.ravel(),
                                                                            self.statistics_array[i].best_y_proba.ravel())
            average_precision["micro"] = average_precision_score(self.y_test, self.statistics_array[i].best_y_proba,
                                                                 average="micro")
            plt.tight_layout()
            #plt.axhline(y=average_precision["micro"], lw=1, linestyle='--',
                        #label='{} AP:{:.2f}'.format("Micro", average_precision["micro"]))

            # stampanje micro PR krive
            plt.plot(precision["micro"], recall["micro"], lw=1,
                     label='{} {:.3f}'.format("micro AP:", average_precision["micro"]))

            plt.xlabel("recall")
            plt.ylabel("precision")
            plt.legend(loc="best")

            full_file_name_pr = self.path + '/' + self.statistics_array[i].method + ' ' + self.statistics_array[
                0].dataset + ' ' \
                                 + self.statistics_array[0].problem + ' PR.pdf'

            title = self.statistics_array[i].method + ' ' + self.statistics_array[
                i].dataset + ' PR curve'

            if self.display_features:
                title = title +  ' \n (' + str(round(self.statistics_array[i].best_feature_size, 2)) + ' sel.feat.)'


            plt.title(title)

            plt.savefig(full_file_name_pr + '.pdf', bbox_inches='tight')
            #sada dodajemo average precision u global statistics array
            self.global_roc_pr_statistics[i]['PR AUC']=str(average_precision)



            #print('Average precision score, micro-averaged over all classes: {0:0.2f}'
                  #.format(average_precision["micro"]))
            #print("\n")
            #print(average_precision["micro"], average_precision, precision, recall, auc_score, f1_result)

            # vraca average precision za sve klase i precision i recall za posebne klase
            # dodatno vraca i auc score i f1_score
            #return average_precision["micro"], average_precision, precision, recall, auc_score, f1_result


    #metoda za generisanje df za objective i error za najbolja resenja u runovima
    #ovde cuvamo za svaku kolonu vrednosti najboljih runova za svaki metod
    def generate_best_run_df(self):

        # pravimo 2 liste, jednu za najbolje objective u runovima, a drugi za najbolje errore u najboljem runu
        # i jednu listu za headere, tj. nazive metoda
        objective_runs = []
        error_runs = []
        headers = ['Run']
        # dodajemo prvu kolonu da budu runovi od 1 pa nadalje,ali krecemo od 1, ne od 0
        objective_runs.append(np.array([x for x in range(1, self.run_number+1)]))
        error_runs.append(np.array([x for x in range(1, self.run_number+1)]))
        # sada ubacujemo elemente u liste
        for i in range(len(self.statistics_array)):
            #ovde proveravamo ako je u pitanju objective onda idemo objective, ako nije, onda ovaj drugi
            if self.statistics_array[i].objective == 'objective':
                objective_runs.append((1-self.statistics_array[i].run_array_best))
                error_runs.append(self.statistics_array[i].run_array_best1)
                headers.append(self.statistics_array[i].method)
                #ako je error glavni, onda je objective run_array_best1, a error je run_array_best
            elif self.statistics_array[i].objective == 'error':
                objective_runs.append(self.statistics_array[i].run_array_best1)
                error_runs.append(self.statistics_array[i].run_array_best)
                headers.append(self.statistics_array[i].method)

        # sada cuvamo dataframe i dodajemo kao atribut klasi Postprocessing
        self.objective_runs_df = pd.DataFrame(data=objective_runs, index=None).T
        self.error_runs_df = pd.DataFrame(data=error_runs, index=None).T
        self.objective_runs_df.columns = headers
        self.error_runs_df.columns = headers

        full_file_name_error = self.path + '/' + self.statistics_array[0].dataset + ' ' + self.statistics_array[
            0].problem + ' error best runs.csv'

        full_file_name_objective = self.path + '/' + self.statistics_array[0].dataset + ' ' + self.statistics_array[
            0].problem + ' objective best runs.csv'

        self.error_runs_df.to_csv(full_file_name_error)
        self.objective_runs_df.to_csv(full_file_name_objective)

    #metoda za generisanje boxplotova za objective i za error
    def generateBoxPlot(self):
        #za ove potrebe koristimo generisane pomocu funkcije generate_runs_df dataframeove
        #self.objective_runs_df i self.error_runs_df

        #pravimo pomocne dataframes
        objective_runs_df = self.objective_runs_df.copy()
        error_runs_df = self.error_runs_df.copy()
        #sada dropujemo kolonu Run
        objective_runs_df.drop('Run',axis=1,inplace=True)
        error_runs_df.drop('Run', axis=1, inplace=True)
        # first we need to melt pandas
        objective_runs_df_melted = pd.melt(objective_runs_df)
        error_runs_df_melted = pd.melt(error_runs_df)
        # postavljamo nove kolone za melted
        objective_runs_df_melted.columns = ['Algorithm', 'Objective']
        error_runs_df_melted.columns = ['Algorithm', str(self.statistics_array[0].indicator)]

        #objective_runs_df_melted.to_csv('test.csv')


        #sada plotujemo i cuvamo
        plt.clf()
        plt.figure(figsize=(20,8),dpi=300)
        #prvo gledamo za objective
        sns.boxplot(x='Algorithm', y='Objective', data=objective_runs_df_melted)
        plt.title(self.statistics_array[0].dataset + ' objective box plot diagram')
        #plt.legend(loc='upper right')

        full_file_name_objective_box_plot = self.path + '/' + self.statistics_array[0].dataset + ' ' + self.statistics_array[
            0].problem + ' objective box plot diagram.pdf'
        plt.savefig(full_file_name_objective_box_plot,bbox_inches='tight')

        #sada gledamo za error

        plt.clf()
        plt.figure(figsize=(20, 8), dpi=300)

        sns.boxplot(x='Algorithm', y=str(self.statistics_array[0].indicator), data=error_runs_df_melted)
        plt.title(self.statistics_array[0].dataset + str(self.statistics_array[0].indicator) + ' box plot diagram')
        # plt.legend(loc='upper right')

        full_file_name_objective_box_plot = self.path + '/' + self.statistics_array[0].dataset + ' ' + \
                                            self.statistics_array[
                                                0].problem + ' ' + str(self.statistics_array[0].indicator) + ' box plot diagram.pdf'
        plt.savefig(full_file_name_objective_box_plot, bbox_inches='tight')

        plt.clf()

        # metoda za generisanje boxplotova za objective i za error
    def generateViolinPlot(self):
        # za ove potrebe koristimo generisane pomocu funkcije generate_runs_df dataframeove
        # self.objective_runs_df i self.error_runs_df

        # pravimo pomocne dataframes
        objective_runs_df = self.objective_runs_df.copy()
        error_runs_df = self.error_runs_df.copy()
        # sada dropujemo kolonu Run
        objective_runs_df.drop('Run', axis=1, inplace=True)
        error_runs_df.drop('Run', axis=1, inplace=True)
        # first we need to melt pandas
        objective_runs_df_melted = pd.melt(objective_runs_df)
        error_runs_df_melted = pd.melt(error_runs_df)
        # postavljamo nove kolone za melted
        objective_runs_df_melted.columns = ['Algorithm', 'Objective']
        error_runs_df_melted.columns = ['Algorithm', str(self.statistics_array[0].indicator)]

        # objective_runs_df_melted.to_csv('test.csv')

        # sada plotujemo i cuvamo
        plt.clf()
        plt.figure(figsize=(20, 8), dpi=300)
        # prvo gledamo za objective
        sns.violinplot(x='Algorithm', y='Objective', data=objective_runs_df_melted,inner='quartile')
        plt.title(self.statistics_array[0].dataset + ' objective violin plot diagram')
        # plt.legend(loc='upper right')

        full_file_name_violin_plot = self.path + '/' + self.statistics_array[0].dataset + ' ' + \
                                            self.statistics_array[
                                                0].problem + ' objective violin plot diagram.pdf'
        plt.savefig(full_file_name_violin_plot, bbox_inches='tight')

        # sada gledamo za error

        plt.clf()
        plt.figure(figsize=(20, 8), dpi=300)

        sns.violinplot(x='Algorithm', y=str(self.statistics_array[0].indicator), data=error_runs_df_melted,inner='quartile')
        plt.title(self.statistics_array[0].dataset + str(self.statistics_array[0].indicator) + ' violin plot diagram')
        # plt.legend(loc='upper right')

        full_file_name_objective_box_plot = self.path + '/' + self.statistics_array[0].dataset + ' ' + \
                                            self.statistics_array[
                                                0].problem + ' ' + str(
            self.statistics_array[0].indicator) + ' violin plot diagram.pdf'
        plt.savefig(full_file_name_objective_box_plot, bbox_inches='tight')

        plt.clf()

    #one versus rest (OvR) i one versus one (OvO) ROC krive generisanje

    # pogledati ovo za ROC za Ovo i Ovr
    # https://github.com/vinyluis/Articles/blob/main/ROC%20Curve%20and%20ROC%20AUC/ROC%20Curve%20-%20Multiclass.ipynb
    # https: // towardsdatascience.com / multiclass - classification - evaluation - with-roc - curves - and -roc - auc - 294fd4617e3a

    #pomocne metode
    def calculate_tpr_fpr(self,y_real, y_pred):
        '''
        Calculates the True Positive Rate (tpr) and the True Negative Rate (fpr) based on real and predicted observations

        Args:
            y_real: The list or series with the real classes
            y_pred: The list or series with the predicted classes

        Returns:
            tpr: The True Positive Rate of the classifier
            fpr: The False Positive Rate of the classifier
        '''

        # Calculates the confusion matrix and recover each element
        cm = confusion_matrix(y_real, y_pred)
        TN = cm[0, 0]
        FP = cm[0, 1]
        FN = cm[1, 0]
        TP = cm[1, 1]

        # Calculates tpr and fpr
        tpr = TP / (TP + FN)  # sensitivity - true positive rate
        fpr = 1 - TN / (TN + FP)  # 1-specificity - false positive rate

        return tpr, fpr

    def get_all_roc_coordinates(self,y_real, y_proba):
        '''
        Calculates all the ROC Curve coordinates (tpr and fpr) by considering each point as a treshold for the predicion of the class.

        Args:
            y_real: The list or series with the real classes.
            y_proba: The array with the probabilities for each class, obtained by using the `.predict_proba()` method.

        Returns:
            tpr_list: The list of TPRs representing each threshold.
            fpr_list: The list of FPRs representing each threshold.
        '''
        tpr_list = [0]
        fpr_list = [0]
        for i in range(len(y_proba)):
            threshold = y_proba[i]
            y_pred = y_proba >= threshold
            tpr, fpr = self.calculate_tpr_fpr(y_real, y_pred)
            tpr_list.append(tpr)
            fpr_list.append(fpr)
        return tpr_list, fpr_list

    def plot_roc_curve(self,tpr, fpr, scatter=True, ax=None):
        '''
        Plots the ROC Curve by using the list of coordinates (tpr and fpr).

        Args:
            tpr: The list of TPRs representing each coordinate.
            fpr: The list of FPRs representing each coordinate.
            scatter: When True, the points used on the calculation will be plotted with the line (default = True).
        '''
        if ax == None:
            plt.clf()
            plt.figure(figsize=(20, 20))
            ax = plt.axes()
        if scatter:
            sns.scatterplot(x=fpr, y=tpr, ax=ax)
        sns.lineplot(x=fpr, y=tpr, ax=ax)
        sns.lineplot(x=[0, 1], y=[0, 1], color='green', ax=ax)
        plt.xlim(-0.05, 1.05)
        plt.ylim(-0.05, 1.05)
        plt.xlabel("FPR")
        plt.ylabel("TPR")
        plt.tight_layout()

    #metoda za plotovanje ROC OvR
    def plotROCOvR(self):
        #idemo kroz sve metode
        for i in range(len(self.statistics_array)):
            n_classes = len(self.classes)
            # prvo pravimo za predikcije u formi klasa i u formi [0,1],[1,0],itd.
            # y je u formi [0,1],[1,0], a y_classes u formi [0,1,1,0,1]
            y, y_classes = self.generateY(self.statistics_array[i].best_y_proba)
            bins = [i / 20 for i in range(20)] + [1]
            roc_auc_ovr = {}

            #plt.clf()

            title = self.statistics_array[i].method + ' ' + self.statistics_array[
                i].dataset + ' ROC OvR'
            if self.display_features:
                title = title+ ' ' + ' \n (' + str(round(self.statistics_array[i].best_feature_size, 2)) + ' sel.feat.)'
            #plt.title(title)
            plt.figure().suptitle(title)




            for j in range(len(self.classes)):
                # Gets the class
                #u nasem slucaju nazivi klasa nisu kategoricki, vec numbericki, 0,1,2,3, itd.
                c = j
                # Prepares an auxiliar dataframe to help with the plots
                df_aux = self.x_test.copy()
                df_aux = pd.DataFrame(df_aux)

                #print(y_classes)
                #print(self.y_test_classes)
                df_aux['class'] = [1 if y1 == c else 0 for y1 in self.y_test_classes]
                df_aux['prob'] = self.statistics_array[i].best_y_proba[:, j]
                df_aux = df_aux.reset_index(drop=True)

                #plt.tight_layout()

                # Plots the probability distribution for the class and the rest
                ax = plt.subplot(2, len(self.classes), j + 1)
                sns.histplot(x="prob", data=df_aux, hue='class', color='b', ax=ax, bins=bins)
                #ax.set_title(c)
                #ax.legend([f"Class: {c}", "Rest"])
                #ax.set_xlabel(f"P(x = {c})")
                ax.set_title(self.classes[j])
                ax.legend([f"Class: {self.classes[j]}", "Rest"])
                ax.set_xlabel(f"P(x = {self.classes[j]})")

                # Calculates the ROC Coordinates and plots the ROC Curves
                ax_bottom = plt.subplot(2, len(self.classes), j + len(self.classes)+1)
                tpr, fpr = self.get_all_roc_coordinates(df_aux['class'], df_aux['prob'])
                self.plot_roc_curve(tpr, fpr, scatter=False, ax=ax_bottom)
                ax_bottom.set_title("ROC Curve OvR")


                # Calculates the ROC AUC OvR
                roc_auc_ovr[c] = roc_auc_score(df_aux['class'], df_aux['prob'])


            plt.tight_layout()

            full_file_name_roc_ovr = self.path + '/' + self.statistics_array[i].method + ' ' + self.statistics_array[
                0].dataset + ' ' + self.statistics_array[0].problem + ' ROC Curve OvR.pdf'
            #plt.tight_layout()
            plt.savefig(full_file_name_roc_ovr,bbox_inches='tight')

            #sada ubacujemo podatke zajedno sa average u globalni niz za statistiku
            #ali prvo racunamo averaga

            avg_roc_auc = 0
            p = 0
            for k in roc_auc_ovr:
                avg_roc_auc += roc_auc_ovr[k]
                p += 1
                #print(f"{k} ROC AUC OvR: {roc_auc_ovr[k]:.4f}")
            roc_auc_ovr['Average'] = avg_roc_auc / p

            #sada dodajemo u globalni niz zajedno sa average
            self.global_roc_pr_statistics[i]['ROC AUC OvR'] = str(roc_auc_ovr)

            #print(f"average ROC AUC OvR: {avg_roc_auc / i:.4f}")

    # metoda za plotovanje ROC OvO
    def plotROCOvO(self):
        for i in range(len(self.statistics_array)):
            classes_combinations = []
            #self.classes je kategoricki, treba da ga pretvorimo u integer, klasa 0,1,2 i zato pravimo pomocnu listu
            classes1 = [j1 for j1 in range(len(self.classes))]


            n_classes = len(classes1)
            #print(n_classes)
            if n_classes == 2:
                classes_combinations.append([classes1[0], classes1[1]])
                classes_combinations.append([classes1[1], classes1[0]])
            else:
                for j in range(n_classes):
                    for k in range(j + 1, n_classes):
                        classes_combinations.append([classes1[j], classes1[k]])
                        classes_combinations.append([classes1[k], classes1[j]])

            #print(self.classes)

            bins = [j1 / 20 for j1 in range(20)] + [1]
            roc_auc_ovo = {}

            #plt.clf()

            #plt.figure(figsize=(40, 10))

            title = self.statistics_array[i].method + ' ' + self.statistics_array[
                i].dataset + ' ROC OvO '
            if self.display_features:
                title = title +  ' \n (' + str(round(self.statistics_array[i].best_feature_size, 2)) + ' sel.feat.)'

            # plt.title(title)
            plt.figure().suptitle(title)

            #plt.tight_layout()

            for j in range(len(classes_combinations)):
                comb = classes_combinations[j]
                c1 = comb[0]
                c2 = comb[1]
                c1_index = classes1.index(c1)
                title = str(self.classes[c1]) + " vs " + str(self.classes[c2])
                #title = str(c1) + " vs " + str(c2)
                #print("C1 INDEX",c1_index)

                # Prepares an auxiliar dataframe to help with the plots
                df_aux = self.x_test.copy()
                df_aux = pd.DataFrame(df_aux)

                # print(y_classes)
                # print(self.y_test_classes)
                df_aux['class'] = self.y_test_classes
                df_aux['prob'] = self.statistics_array[i].best_y_proba[:, c1_index]
                #print(self.statistics_array[i].best_y_proba[:,c1_index])
                #print(df_aux)

                # Slices only the subset with both classes
                df_aux = df_aux[(df_aux['class'] == c1) | (df_aux['class'] == c2)]
                df_aux['class'] = [1 if y1 == c1 else 0 for y1 in df_aux['class']]
                df_aux = df_aux.reset_index(drop=True)
                #print(df_aux)

                # Plots the probability distribution for the class and the rest
                ax = plt.subplot(2, len(classes_combinations), j + 1)
                sns.histplot(x="prob", data=df_aux, hue='class', color='b', ax=ax, bins=bins)
                ax.set_title(title)
                #ax.legend([f"Class: {c1}", f"Class: {c2}"])
                #ax.set_xlabel(f"P(x = {c1})")
                ax.legend([f"Class: {self.classes[c1]}", f"Class: {self.classes[c2]}"])
                ax.set_xlabel(f"P(x = {self.classes[c1]})")


                # Calculates the ROC Coordinates and plots the ROC Curves
                ax_bottom = plt.subplot(2, len(classes_combinations), j + 1 + len(classes_combinations))
                tpr, fpr = self.get_all_roc_coordinates(df_aux['class'], df_aux['prob'])
                self.plot_roc_curve(tpr, fpr, scatter=False, ax=ax_bottom)
                ax_bottom.set_title("ROC Curve OvO")
                #plt.tight_layout()

                # Calculates the ROC AUC OvO
                roc_auc_ovo[title] = roc_auc_score(df_aux['class'], df_aux['prob'])
            #plt.tight_layout()
            #plt.show()
            #print(roc_auc_ovo)

            full_file_name_roc_ovo = self.path + '/' + self.statistics_array[i].method + ' ' + self.statistics_array[
                0].dataset + ' ' + self.statistics_array[0].problem + ' ROC Curve OvO.pdf'
            #plt.tight_layout()
            plt.savefig(full_file_name_roc_ovo,bbox_inches='tight')
            plt.tight_layout()

            # sada ubacujemo podatke zajedno sa average u globalni niz za statistiku
            # ali prvo racunamo averaga

            avg_roc_auc = 0
            p = 0
            for k in roc_auc_ovo:
                avg_roc_auc += roc_auc_ovo[k]
                p += 1
                # print(f"{k} ROC AUC OvR: {roc_auc_ovr[k]:.4f}")
            roc_auc_ovo['Average'] = avg_roc_auc / p

            # sada dodajemo u globalni niz zajedno sa average
            self.global_roc_pr_statistics[i]['ROC AUC OvO'] = str(roc_auc_ovo)

            # print(f"average ROC AUC OvR: {avg_roc_auc / i:.4f}")




    #pomocna metoda za cuvanje metrika u csv fajl za global statistics za ROC i PR
    def savePRROCstatistics(self):
        #pravimo prvo headere
        headers = ['Method','ROC AUC','PR AUC','ROC AUC OvR','ROC AUC OvO']
        #file path
        full_file_name = self.path + '/' + self.statistics_array[0].dataset + ' ' + self.statistics_array[
            0].problem + ' ' + self.statistics_array[0].objective + ' ROC PR metrics.csv'

        with open(full_file_name, 'w', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=headers)
            writer.writeheader()
            writer.writerows(self.global_roc_pr_statistics)

        # funkcija koja cuva najbolje modele

    def saveBestModels(self):
        for i in range(len(self.statistics_array)):
            if self.model_name == 'LR':
                file_name = str(self.path) + '/' + str(self.statistics_array[i].method) + '_best_model.sav'
                pickle.dump(self.statistics_array[i].best_model, open(file_name, 'wb'))

            elif self.model_name == 'XGBOOST':
                self.statistics_array[i].best_model.save_model(
                    str(self.path) + '/' + str(self.statistics_array[i].method) + '_best_model')
            #ovo je za keras modele
            else:
                self.statistics_array[i].best_model.save(
                    str(self.path) + '/' + str(self.statistics_array[i].method) + '_best_model')

            # ovako se loaduje najbolji model - reconstructed_model = keras.models.load_model("my_model")

        # metoda za generisanje dataframeova sa diversity u poslednjoj populaciji za R2 i mse, ili druge indikatore po potrebi

    def generate_best_diversity(self):

        # pravimo dve liste jednu za sva reseanja sa objective a drugu sa indikatorom (indikator primamo preko konstrtuktora)
        objective_diversity_list = []
        indicator_diversity_list = []
        headers = ['Solutions']
        # dodajemo prvu kolonu da resenja od 1 pa nadalje
        objective_diversity_list.append(
            np.array([x for x in range(1, len(self.statistics_array[0].diversity_objective) + 1)]))
        indicator_diversity_list.append(
            np.array([x for x in range(1, len(self.statistics_array[0].diversity_indicator) + 1)]))

        # print('TEST:',self.statistics_array[0].diversity_objective)
        # print("LEN test:",len(self.statistics_array[0].diversity_objective))

        # sada ubacujemo elemente u liste
        for i in range(len(self.statistics_array)):
            obj_diversity = [1-x for x in self.statistics_array[i].diversity_objective]
            objective_diversity_list.append(np.array(obj_diversity))
            indicator_diversity_list.append(np.array(self.statistics_array[i].diversity_indicator))
            headers.append(self.statistics_array[i].method)
        # print(indicator1_list)

        # print(headers)
        # print(len(headers))

        # sada cuvamo dataframe i dodajemo kao atribut klasi Postprocessing
        self.objective_diversity_list_df = pd.DataFrame(data=objective_diversity_list, index=None).T
        self.indicator_diversity_list_df = pd.DataFrame(data=indicator_diversity_list, index=None).T
        self.objective_diversity_list_df.columns = headers
        self.indicator_diversity_list_df.columns = headers

        full_file_name_indicator1 = self.path + '/' + self.statistics_array[0].dataset + ' objective diversity.csv'
        full_file_name_indicator2 = self.path + '/' + self.statistics_array[0].dataset + str(
            self.statistics_array[0].indicator) + ' diversity.csv'

        self.objective_diversity_list_df.to_csv(full_file_name_indicator1)
        self.indicator_diversity_list_df.to_csv(full_file_name_indicator2)

    # metoda za generisanje swarm plotova disperzije resenja u najboljoj populaciji, poslednja iteracija, gde je best resenje

    def generateSwarmPlotsDiversity(self):
        # za ove potrebe koristimo generisane pomocu funkcije generate_runs_df dataframeove
        # self.objective_runs_df i self.error_runs_df

        # pravimo pomocne dataframes
        objective_diversity_df = self.objective_diversity_list_df.copy()
        indicator_diversity_df = self.indicator_diversity_list_df.copy()
        # sada dropujemo kolonu Solution
        objective_diversity_df.drop('Solutions', axis=1,
                                    inplace=True)  # Objective sta god da je (mse najverovatnije)
        indicator_diversity_df.drop('Solutions', axis=1, inplace=True)  # indicator sta god da je, najverovatnije R2
        # first we need to melt pandas
        objective_diversity_df_melted = pd.melt(objective_diversity_df)
        indicator_diversity_df_melted = pd.melt(indicator_diversity_df)
        # postavljamo nove kolone za melted
        objective_diversity_df_melted.columns = ['Algorithm',
                                                 'Objective']  # Objective sta god da je (mse najverovatnije)
        indicator_diversity_df_melted.columns = ['Algorithm', str(
            self.statistics_array[0].indicator)]  # indicator sta god da je, najverovatnije R2

        # objective_runs_df_melted.to_csv('test.csv')

        # sada plotujemo i cuvamo
        plt.clf()
        # prvo gledamo za objective
        sns.swarmplot(x='Algorithm', y='Objective', data=objective_diversity_df_melted)
        plt.title(self.statistics_array[0].dataset + ' objective swarm plot diversity')
        # plt.legend(loc='upper right')

        full_file_name_objective_box_plot = self.path + '/' + self.statistics_array[
            0].dataset + ' objective swarm plot diversity.pdf'
        plt.savefig(full_file_name_objective_box_plot, bbox_inches='tight')

        # sada gledamo za indicator

        plt.clf()

        sns.swarmplot(x='Algorithm', y=str(self.statistics_array[0].indicator), data=indicator_diversity_df_melted)
        plt.title(
            self.statistics_array[0].dataset + ' ' + str(
                self.statistics_array[0].indicator) + ' swarm plot diversity')
        # plt.legend(loc='upper right')

        full_file_name_indicator_box_plot = self.path + '/' + self.statistics_array[0].dataset + ' ' + str(
            self.statistics_array[0].indicator) + ' swarm plot diversity.pdf'
        plt.savefig(full_file_name_indicator_box_plot, bbox_inches='tight')

        # plt.clf()

    # sada pravimo joint plot za diversifikaciju resenja u najboljoj populaciji, u najboljem runu
    def plotJointPlot(self):
        # lista paleta za razne metode
        colors = ['blue', 'green', 'red', 'black', 'purple', 'royalblue', 'darkorange', 'lightblue', 'indianred']

        for i in range(0, len(self.statistics_array)):
            plt.clf()
            plt.figure(figsize=(10, 5))
            div_objective_diversity = [1 - x for x in self.statistics_array[i].diversity_objective]
            h = sns.jointplot(  # self.statistics_array[i].diversity_objective,
                div_objective_diversity,
                self.statistics_array[i].diversity_indicator, color=colors[i])  # kind='kde')
            h.set_axis_labels('objective', str(self.statistics_array[0].indicator), fontsize=12)
            h.fig.suptitle(
                str(self.statistics_array[i].dataset) + ' ' + str(self.statistics_array[i].method) + ' diversity',
                fontsize=12)
            h.fig.tight_layout()
            h.fig.subplots_adjust(top=0.96)  # Reduce plot to make room
            # plt.title(str(self.statistics_array[0].dataset) + ' ' + str(self.statistics_array[0].method) + ' diversity')
            plt.savefig(self.path + '/' + str(self.statistics_array[i].dataset) + ' ' + str(
                self.statistics_array[i].method) + ' objective indicator joint plot.pdf', bbox_inches='tight')

    def generateKDEPlot(self):
        # za ove potrebe koristimo generisane pomocu funkcije generate_runs_df dataframeove
        # self.objective_runs_df i self.error_runs_df

        # pravimo pomocne dataframes
        objective_runs_df = self.objective_runs_df.copy()
        error_runs_df = self.error_runs_df.copy()
        # sada dropujemo kolonu Run
        objective_runs_df.drop('Run', axis=1, inplace=True)
        error_runs_df.drop('Run', axis=1, inplace=True)

        plt.clf()
        plt.figure(figsize=(12, 8), dpi=200)
        # prvo gledamo za objective

        fig, ax = plt.subplots(figsize=(15, 6), dpi=150)
        sns.kdeplot(data=objective_runs_df, shade=True, palette='Set1', ax=ax)
        # self.move_legend(ax, "upper left")
        plt.title(
            self.statistics_array[0].dataset + ' ' + 'objective KDE plot diagram',
            fontsize=8)

        full_file_name_objective_kde_plot = self.path + '/' + self.statistics_array[
            0].dataset + ' objective KDE plot diagram.pdf'
        plt.savefig(full_file_name_objective_kde_plot, bbox_inches='tight')

        # sada gledamo za indicator

        plt.clf()
        plt.figure(figsize=(12, 8), dpi=200)

        fig, ax = plt.subplots(figsize=(15, 6), dpi=150)
        sns.kdeplot(data=error_runs_df, shade=True, palette='Set1', ax=ax)
        # self.move_legend(ax, "upper left")
        plt.title(
            self.statistics_array[0].dataset + ' ' + str(self.statistics_array[0].indicator) + ' KDE plot diagram',
            fontsize=8)

        full_file_name_indicator_kde_plot = self.path + '/' + self.statistics_array[
            0].dataset + ' ' + str(
            self.statistics_array[0].indicator) + ' KDE plot diagram.pdf'
        plt.savefig(full_file_name_indicator_kde_plot, bbox_inches='tight')



















